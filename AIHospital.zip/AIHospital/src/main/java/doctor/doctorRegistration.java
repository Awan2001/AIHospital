package doctor;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class doctorRegistration
 */
@WebServlet("/doctorRegistration")
public class doctorRegistration extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private doctorModel docModel;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public doctorRegistration() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// Obtain data from the form
				String dfirstname = request.getParameter("dfirstname");
				String dlastname = request.getParameter("dlastname");
				String docno = request.getParameter("docno");
				int docdeptid = Integer.parseInt(request.getParameter("docdeptid"));
						
				//declare object
				Doctor doctor =new Doctor();
						
				doctor.setDocFName(dfirstname);
				doctor.setDocLName(dlastname);
				doctor.setDocNo(docno);
				doctor.setDocDeptID(docdeptid);
				
				
				try {
					docModel = new doctorModel();//initialize inventoryModel obj with InventoryModel method in InventoryModel.java
					docModel.regDoctor(doctor);//passing value of inventory obj to the addInventory method inside the inventoryModel obj
				}
				catch (Exception e) {
							e.printStackTrace();
							System.out.println("No data inserted in the table ");
						}
				response.sendRedirect("viewDoc.jsp");
			}

}
