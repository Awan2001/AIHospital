package doctor;

public class Doctor {
	private int docID;
	private String docFName;
	private String docLName;
	private String docNo;
	private int docDeptID;
	public Doctor(int docID, String docFName, String docLName, String docNo, int docDeptID) {
		super();
		this.docID = docID;
		this.docFName = docFName;
		this.docLName = docLName;
		this.docNo = docNo;
		this.docDeptID = docDeptID;
	}
	public Doctor() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getDocID() {
		return docID;
	}
	public void setDocID(int docID) {
		this.docID = docID;
	}
	public String getDocFName() {
		return docFName;
	}
	public void setDocFName(String docFName) {
		this.docFName = docFName;
	}
	public String getDocLName() {
		return docLName;
	}
	public void setDocLName(String docLName) {
		this.docLName = docLName;
	}
	public String getDocNo() {
		return docNo;
	}
	public void setDocNo(String docNo) {
		this.docNo = docNo;
	}
	public int getDocDeptID() {
		return docDeptID;
	}
	public void setDocDeptID(int docDeptID) {
		this.docDeptID = docDeptID;
	}
	
}
