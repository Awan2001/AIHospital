package doctor;
import department.Department;
import patient.Patient;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class doctorModel {
	private Statement statement; 
	private PreparedStatement ps; 
	private Connection connection;
	public doctorModel(Statement statement, PreparedStatement ps, Connection connection) {
		super();
		this.statement = statement;
		this.ps = ps;
		this.connection = connection;
	}
	public doctorModel() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public void initJDBC() {
		try {
			//load JDBC
			Class.forName("com.mysql.jdbc.Driver");
			
			// Connect to a database
			 connection = DriverManager.getConnection
					("jdbc:mysql://localhost/ai_hospital" , "root", "");

			// Create a statement
			statement = connection.createStatement();
		}catch(Exception e) {
		}	
	}
	public ArrayList<Doctor> viewDoctor(){
		
		ArrayList<Doctor> doctorList = null;
		try {
			initJDBC();
			doctorList = new ArrayList<Doctor>();
			ResultSet rs = statement.executeQuery("SELECT * FROM doctor");
			
			while(rs.next()){
				Doctor doc= new Doctor();
				doc.setDocID(rs.getInt("doc_id"));
				doc.setDocFName(rs.getString("doc_fname"));
				doc.setDocLName(rs.getString("doc_lname"));
				doc.setDocNo(rs.getString("doc_no"));
				doc.setDocDeptID(rs.getInt("dept_id"));
				//either way you also may use normal constructor to set values
				doctorList.add(doc);
			}
			connection.close();
		}
		catch(Exception ex) {
			System.out.println("viewDoctor(): "+ ex);
			ex.printStackTrace();
		}
		
		return doctorList;
	}
	
	public void regDoctor(Doctor doc) {
		initJDBC();
		try {
			//buat sql insert statement
			String sql = "INSERT INTO doctor (doc_fname, doc_lname, doc_no, dept_id)"
		    		+ " VALUES (?, ?, ?, ?)";
			//stmt value index=(1, 2, 3, 4);
			//prepared statement
			PreparedStatement stmt = connection.prepareStatement(sql);
			// Set values for placeholders
		    stmt.setString(1, doc.getDocFName());  //1
		    stmt.setString(2, doc.getDocLName());  //2
		    stmt.setString(3, doc.getDocNo());	   //3
		    stmt.setInt(4, doc.getDocDeptID());    //4

		    
		    //selesai set value bole la execute statement
		    stmt.executeUpdate();
			
		}catch(Exception ex){
			System.out.println("regDoctor(): " +ex);
			ex.printStackTrace();
			
		}
	}
	
	public List<Department> getDepartments() throws SQLException {
        List<Department> departments = new ArrayList<>();

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/ai_hospital", "root", "")) {
            try (Statement statement = connection.createStatement()) {
                try (ResultSet resultSet = statement.executeQuery("SELECT * FROM departments")) {
                    while (resultSet.next()) {
                        int deptId = resultSet.getInt("dept_id");
                        String deptName = resultSet.getString("dept_name");
                        departments.add(new Department(deptId, deptName));
                    }
                }
            }
        }

        return departments;
    }
	public Doctor getDoctorById(int docID) {
		Doctor doctor = new Doctor();
		try {
			initJDBC();
			String findDoc = "SELECT * FROM doctor WHERE doc_id =" + docID;
			ps = connection.prepareStatement(findDoc);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				 
				 doctor.setDocID(rs.getInt(1));
				 doctor.setDocFName(rs.getString(2));
				 doctor.setDocLName(rs.getString(3));
				 doctor.setDocNo(rs.getString(4));
				 doctor.setDocDeptID(rs.getInt(5)); 
			 }
		}catch(Exception ex){
			System.out.println("getDoctorById(): " +ex);
			ex.printStackTrace();
		}
		
		return doctor;
	}
	public void updateDoctor(Doctor doc){
		 
		initJDBC();
		
		try{			
			String sqlUpdate = "UPDATE doctor SET doc_fname = ?, doc_lname = ?,"
					+ " doc_no = ?, dept_id = ?"
					+ " WHERE doc_id = ?";
			
		    PreparedStatement stmt = connection.prepareStatement(sqlUpdate);
		    
			stmt.setString(1, doc.getDocFName());
			stmt.setString(2, doc.getDocLName());
			stmt.setString(3, doc.getDocNo());
			stmt.setInt(4, doc.getDocDeptID());
			stmt.setInt(5, doc.getDocID());
			
			//ps.executeUpdate();
			int i = stmt.executeUpdate();
			
		}catch(Exception ex){
			System.out.println("updateDoctor(): "+ex);
			ex.printStackTrace();	
		}
	}
	public String getDoctName(int docID) {
        Doctor doc  = new Doctor();
        try {
            initJDBC();
            String findName = "SELECT doc_fname, doc_lname FROM doctor WHERE doc_id = ?";
            ps = connection.prepareStatement(findName);
            ps.setInt(1, docID); // Bind the parameter
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                doc.setDocFName(rs.getString("doc_fname"));
                doc.setDocLName(rs.getString("doc_lname"));
            } else {
                System.out.println("No doctor found for doc_id: " + docID);
            }

            connection.close();
        } catch (Exception ex) {
            System.out.println("getDoctName(): " + ex);
            ex.printStackTrace();
        }

        return doc.getDocFName()+" "+doc.getDocLName();
    }
	public int docCount() {
	    int rowCount = 0;
	    try {
	        initJDBC();
	        String countDocs = "SELECT COUNT(*) AS rowCount FROM doctor";
	        ps = connection.prepareStatement(countDocs);
	        ResultSet rs = ps.executeQuery();

	        if (rs.next()) {
	            rowCount = rs.getInt("rowCount");
	        }

	        connection.close();
	    } catch (Exception ex) {
	        System.out.println("docCount(): " + ex);
	        ex.printStackTrace();
	    }
	    return rowCount;
	}
	public List<Integer> getDoctorCountByDepartment() {
	    List<Integer> doctorCounts = new ArrayList<>();

	    try {
	        initJDBC();
	        String countDocsByDept = "SELECT dept_id, COUNT(*) AS rowCount FROM doctor GROUP BY dept_id";
	        ps = connection.prepareStatement(countDocsByDept);
	        ResultSet rs = ps.executeQuery();

	        while (rs.next()) {
	            int departmentId = rs.getInt("dept_id");
	            int rowCount = rs.getInt("rowCount");
	            doctorCounts.add(rowCount);
	        }

	        connection.close();
	    } catch (Exception ex) {
	        System.out.println("getDoctorCountByDepartment(): " + ex);
	        ex.printStackTrace();
	    }

	    return doctorCounts;
	}

}