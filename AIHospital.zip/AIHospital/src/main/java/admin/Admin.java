package admin;

public class Admin {
	private int adminID;
	private String adminFname;
	private String adminLname;
	private String adminNo;
	private String adminPass;
	private String adminUsername;
	public Admin(int adminID, String adminFname, String adminLname, String adminNo, String adminPass,
			String adminUsername) {
		super();
		this.adminID = adminID;
		this.adminFname = adminFname;
		this.adminLname = adminLname;
		this.adminNo = adminNo;
		this.adminPass = adminPass;
		this.adminUsername = adminUsername;
	}
	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getAdminID() {
		return adminID;
	}
	public void setAdminID(int adminID) {
		this.adminID = adminID;
	}
	public String getAdminFname() {
		return adminFname;
	}
	public void setAdminFname(String adminFname) {
		this.adminFname = adminFname;
	}
	public String getAdminLname() {
		return adminLname;
	}
	public void setAdminLname(String adminLname) {
		this.adminLname = adminLname;
	}
	public String getAdminNo() {
		return adminNo;
	}
	public void setAdminNo(String adminNo) {
		this.adminNo = adminNo;
	}
	public String getAdminPass() {
		return adminPass;
	}
	public void setAdminPass(String adminPass) {
		this.adminPass = adminPass;
	}
	public String getAdminUsername() {
		return adminUsername;
	}
	public void setAdminUsername(String adminUsername) {
		this.adminUsername = adminUsername;
	}
	
}
