package admin;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class adminLoginHandler
 */
@WebServlet("/adminLoginHandler")
public class adminLoginHandler extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public adminLoginHandler() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// Get the IC Number and Password from the login form
        String adminUsername = request.getParameter("adminUsername");
        String adminPassword = request.getParameter("adminPassword");

        // Create an instance of the patientModel class
        adminModel adminModel = new adminModel();
        // Initialize JDBC connection
        adminModel.initJDBC();

        // Validate the login credentials
        boolean isValidLogin = adminModel.adminValidateLogin(adminUsername, adminPassword);

        if (isValidLogin) {
            // If login is successful, redirect the patient to a dashboard page or any other authenticated page.
        	HttpSession session = request.getSession();
        	session.setAttribute("adminUsername", adminUsername);
        	session.setAttribute("adminID", adminModel.getAdminID(adminUsername));
            session.setAttribute("status", "adminloggedin");
            response.sendRedirect("index.jsp");
        } 		
        else {
			HttpSession session = request.getSession();
			session.setAttribute("danger", "Login failed... Please enter the correct Username and Password!");
			response.sendRedirect("adminlogin.jsp");
		}
	}

}
