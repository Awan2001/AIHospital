package admin;
import java.sql.*;

public class adminModel {
	private Statement statement; 
	private PreparedStatement ps; 
	private Connection connection;
	public adminModel(Statement statement, PreparedStatement ps, Connection connection) {
		super();
		this.statement = statement;
		this.ps = ps;
		this.connection = connection;
	}
	public adminModel() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public void initJDBC() {
		try {
			//load JDBC
			Class.forName("com.mysql.jdbc.Driver");
			
			// Connect to a database
			 connection = DriverManager.getConnection
					("jdbc:mysql://localhost/ai_hospital" , "root", "");

			// Create a statement
			statement = connection.createStatement();
		}catch(Exception e) {
		}	
	 }
	public boolean adminValidateLogin(String adminUsername, String adminpassword) {
		
        boolean isValidLogin = false;
        try {
        	initJDBC();
            // Prepare the SQL query with placeholders
            String query = "SELECT * FROM admin WHERE admin_username = ? AND admin_pass = ?";
            try (PreparedStatement ps = connection.prepareStatement(query)) {
                // Set the placeholder values
                ps.setString(1, adminUsername);
                ps.setString(2, adminpassword);

                // Execute the query
                try (ResultSet rs = ps.executeQuery()) {
                    // Check if a matching patient is found
                    isValidLogin = rs.next();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return isValidLogin;
    }
	public int getAdminID(String username) {
		int adminID = 0;
		try {
			initJDBC();
			String query = "SELECT admin_id FROM admin WHERE admin_username = ?";
			ps = connection.prepareStatement(query);
            ps.setString(1, username); // Bind the parameter
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
            	adminID = rs.getInt("admin_id");
            } else {
                System.out.println("No admin found for admin_username: " + username);
            }

            connection.close();
			
		}catch(Exception e){
			
		}
		return adminID;
	}
	public String getAdminName(int adminID) {
        Admin adm  = new Admin();
        try {
            initJDBC();
            String findName = "SELECT admin_fname, admin_lname FROM admin WHERE admin_id = ?";
            ps = connection.prepareStatement(findName);
            ps.setInt(1, adminID); // Bind the parameter
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                adm.setAdminFname(rs.getString("admin_fname"));
                adm.setAdminLname(rs.getString("admin_lname"));
            } else {
                System.out.println("No admin found for admin_id: " + adminID);
            }

            connection.close();
        } catch (Exception ex) {
            System.out.println("getAdminName(): " + ex);
            ex.printStackTrace();
        }

        return adm.getAdminFname()+" "+adm.getAdminLname();
    }

}
