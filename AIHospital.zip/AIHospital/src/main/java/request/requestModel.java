package request;

import java.sql.*;
import java.util.ArrayList;

public class requestModel {
	private Statement statement; 
	private PreparedStatement ps; 
	private Connection connection;
	public requestModel(Statement statement, PreparedStatement ps, Connection connection) {
		super();
		this.statement = statement;
		this.ps = ps;
		this.connection = connection;
	}
	public requestModel() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public void initJDBC() {
		try {
			//load JDBC
			Class.forName("com.mysql.jdbc.Driver");
			
			// Connect to a database
			 connection = DriverManager.getConnection
					("jdbc:mysql://localhost/ai_hospital" , "root", "");

			// Create a statement
			statement = connection.createStatement();
		}catch(Exception e) {
		}	
	 }
	public void reqAppointment(Request req) {
		try {
			initJDBC();
			String sql = "INSERT INTO request (pt_ic, req_desc, req_status)"
		    		+ " VALUES (?, ?, ?)";
			PreparedStatement stmt = connection.prepareStatement(sql);
			// Set values for placeholders
		    stmt.setString(1, req.getIcNumber());  //1
		    stmt.setString(2, req.getReqDesc());  //2
		    stmt.setString(3, req.getReqStatus());	   //3
		    
		  //selesai set value bole la execute statement
		    stmt.executeUpdate();
		    
		}catch(Exception ex){
			System.out.println("reqAppointment(): " +ex);
			ex.printStackTrace();
			
		}
	}
	public ArrayList<Request> viewRequest(){
		
		ArrayList<Request> requestList = null;
		try {
			initJDBC();
			requestList = new ArrayList<Request>();
			ResultSet rs = statement.executeQuery("SELECT * FROM request WHERE req_status = 'pending';");
			
			while(rs.next()){
				Request req= new Request();
				req.setIcNumber(rs.getString("pt_ic"));
				req.setReqID(rs.getInt("req_id"));
				req.setReqDesc(rs.getString("req_desc"));
				req.setReqStatus(rs.getString("req_status"));
				//either way you also may use normal constructor to set values
				requestList.add(req);
			}
			connection.close();
		}
		catch(Exception ex) {
			System.out.println("viewRequest(): "+ ex);
			ex.printStackTrace();
		}
		
		return requestList;
	}
	public void updateReq(int reqID){
		 
		initJDBC();
		
		try{			
			String sqlUpdate = "UPDATE request SET req_status = 'completed'"
					+ " WHERE req_id = ?";
			
		    PreparedStatement stmt = connection.prepareStatement(sqlUpdate);
		    
			stmt.setInt(1, reqID);
			
			//ps.executeUpdate();
			int i = stmt.executeUpdate();
			
		}catch(Exception ex){
			System.out.println("updateReq(): "+ex);
			ex.printStackTrace();	
		}
	}
}
