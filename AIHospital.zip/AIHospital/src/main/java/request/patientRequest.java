package request;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class patientRequest
 */
@WebServlet("/patientRequest")
public class patientRequest extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private requestModel reqModel;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public patientRequest() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String icno = request.getParameter("icNumber");
		String patreq = request.getParameter("ptrequest");
		String statusReq = request.getParameter("statusReq");
		
		Request ptrequest = new Request();
		
		ptrequest.setIcNumber(icno);
		ptrequest.setReqDesc(patreq);
		ptrequest.setReqStatus(statusReq);
		
		try {
			reqModel = new requestModel();//initialize inventoryModel obj with InventoryModel method in InventoryModel.java
			reqModel.reqAppointment(ptrequest);//passing value of inventory obj to the addInventory method inside the inventoryModel obj
		}
		catch (Exception e) {
					e.printStackTrace();
					System.out.println("No data inserted in the table ");
				}
		
		response.sendRedirect("index.jsp");
	}

}
