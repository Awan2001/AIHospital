package request;

public class Request {
	private String icNumber;
	private int reqID;
	private String reqDesc;
	private String reqStatus;
	public Request(String icNumber, int reqID, String reqDesc, String reqStatus) {
		super();
		this.icNumber = icNumber;
		this.reqID = reqID;
		this.reqDesc = reqDesc;
		this.reqStatus = reqStatus;
	}
	public Request() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getIcNumber() {
		return icNumber;
	}
	public void setIcNumber(String icNumber) {
		this.icNumber = icNumber;
	}
	public int getReqID() {
		return reqID;
	}
	public void setReqID(int reqID) {
		this.reqID = reqID;
	}
	public String getReqDesc() {
		return reqDesc;
	}
	public void setReqDesc(String reqDesc) {
		this.reqDesc = reqDesc;
	}
	public String getReqStatus() {
		return reqStatus;
	}
	public void setReqStatus(String reqStatus) {
		this.reqStatus = reqStatus;
	}
}
