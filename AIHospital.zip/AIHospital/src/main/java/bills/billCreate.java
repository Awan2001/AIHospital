package bills;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class billCreate
 */
@WebServlet("/billCreate")
public class billCreate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private billModel billM;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public billCreate() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		int appid = Integer.parseInt(request.getParameter("appid"));
		String billstatus = request.getParameter("billstatus");
		String billmethod = request.getParameter("billmethod");
		String icnum = request.getParameter("icnum");
		double billamount = Double.parseDouble(request.getParameter("billamount"));
		
		Bill bill = new Bill();
		bill.setAppId(appid);
		bill.setBillStatus(billstatus);
		bill.setBillMethod(billmethod);
		bill.setPtIc(icnum);
		bill.setBillAmmount(billamount);
		
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		Date billdate = null;
				
		try{
			billdate = format.parse(request.getParameter("billdate"));
			bill.setBillDate(billdate);
		} catch(ParseException e){
			e.printStackTrace();
		}
		
		try {
			billM = new billModel();//initialize inventoryModel obj with InventoryModel method in InventoryModel.java
			billM.billAdd(bill);//passing value of inventory obj to the addInventory method inside the inventoryModel obj
		}
		catch (Exception e) {
					e.printStackTrace();
					System.out.println("No data inserted in the table ");
				}
		response.sendRedirect("viewApp.jsp");
		
	}

}
