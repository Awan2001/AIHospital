package bills;

import java.sql.*;
import java.util.ArrayList;

import doctor.Doctor;

public class billModel {
	private Statement statement; 
	private PreparedStatement ps; 
	private Connection connection;
	public billModel(Statement statement, PreparedStatement ps, Connection connection) {
		super();
		this.statement = statement;
		this.ps = ps;
		this.connection = connection;
	}
	public billModel() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public void initJDBC() {
		try {
			//load JDBC
			Class.forName("com.mysql.jdbc.Driver");
			
			// Connect to a database
			 connection = DriverManager.getConnection
					("jdbc:mysql://localhost/ai_hospital" , "root", "");

			// Create a statement
			statement = connection.createStatement();
		}catch(Exception e) {
		}	
	}
	
	public void billAdd(Bill bill) {
		initJDBC();
		try {
			//buat sql insert statement
			String sql = "INSERT INTO bills (app_id, bills_date, bills_status, bill_amount,bill_method,pt_ic)"
		    		+ " VALUES (?, ?, ?, ?, ?, ?)";
			
			//prepared statement
			PreparedStatement stmt = connection.prepareStatement(sql);
			// Set values for placeholders
		    stmt.setInt(1, bill.getAppId());
		    stmt.setDate(2, new Date(bill.getBillDate().getTime()));
		    stmt.setString(3, bill.getBillStatus());
		    stmt.setDouble(4, bill.getBillAmmount());
		    stmt.setString(5, bill.getBillMethod());
		    stmt.setString(6, bill.getPtIc());
		    

		    
		    //selesai set value bole la execute statement
		    stmt.executeUpdate();
			
		}catch(Exception ex){
			System.out.println("billAdd(): " +ex);
			ex.printStackTrace();
			
		}
	}
	public ArrayList<Bill> viewBill(){
		ArrayList<Bill> billList = null;
		
		try {
			initJDBC();
			billList = new ArrayList<Bill>();
			ResultSet rs = statement.executeQuery("SELECT * FROM bills");
			
			while(rs.next()){
				Bill bill= new Bill();
				bill.setBillId(rs.getInt("bills_id"));
				bill.setAppId(rs.getInt("app_id"));
				bill.setBillDate(rs.getDate("bills_date"));
				bill.setBillStatus(rs.getString("bills_status"));
				bill.setBillAmmount(rs.getDouble("bill_amount"));
				bill.setBillMethod(rs.getString("bill_method"));
				bill.setPtIc(rs.getString("pt_ic"));
				
				//either way you also may use normal constructor to set values
				billList.add(bill);
			}
			connection.close();
		}
		catch(Exception ex) {
			System.out.println("viewBill(): "+ ex);
			ex.printStackTrace();
		}
		
		return billList;
	}
	public ArrayList<Bill> viewBillPatient(String ic){
		ArrayList<Bill> billList = null;
		
		try {
			initJDBC();
			billList = new ArrayList<Bill>();
			ResultSet rs = statement.executeQuery("SELECT * FROM bills where pt_ic ="+ic);
			
			while(rs.next()){
				Bill bill= new Bill();
				bill.setBillId(rs.getInt("bills_id"));
				bill.setAppId(rs.getInt("app_id"));
				bill.setBillDate(rs.getDate("bills_date"));
				bill.setBillStatus(rs.getString("bills_status"));
				bill.setBillAmmount(rs.getDouble("bill_amount"));
				bill.setBillMethod(rs.getString("bill_method"));
				bill.setPtIc(rs.getString("pt_ic"));
				
				//either way you also may use normal constructor to set values
				billList.add(bill);
			}
			connection.close();
		}
		catch(Exception ex) {
			System.out.println("viewBillPatient(): "+ ex);
			ex.printStackTrace();
		}
		
		return billList;
	}
	public Bill getBillById(int billid) {
		Bill bill = new Bill();
		try {
			initJDBC();
			String findBill = "SELECT * FROM bills WHERE bills_id =" + billid;
			ps = connection.prepareStatement(findBill);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				 
				 bill.setBillId(rs.getInt(1));
				 bill.setAppId(rs.getInt(2));
				 bill.setBillDate(rs.getDate(3));
				 bill.setBillStatus(rs.getString(4));
				 bill.setBillAmmount(rs.getDouble(5));
				 bill.setBillMethod(rs.getString(6));
				 bill.setPtIc(rs.getString(7));
				 
			}
		}catch(Exception ex){
			System.out.println("getBillById(): " +ex);
			ex.printStackTrace();
		}
		
		return bill;
	}
	public void updateStatus(Bill bill) {
	    initJDBC();

	    try {
	        String sqlUpdate = "UPDATE bills SET bills_status = ?, bill_method = ?, app_id = ?, " +
	                           "bills_date = ?, bill_amount = ?, pt_ic = ? WHERE bills_id = ?";

	        PreparedStatement stmt = connection.prepareStatement(sqlUpdate);

	        stmt.setString(1, bill.getBillStatus());
	        stmt.setString(2, bill.getBillMethod());
	        stmt.setInt(3, bill.getAppId());
	        stmt.setDate(4, new Date(bill.getBillDate().getTime()));
	        stmt.setDouble(5, bill.getBillAmmount());
	        stmt.setString(6, bill.getPtIc());
	        stmt.setInt(7, bill.getBillId());

	        stmt.executeUpdate();

	    } catch (Exception ex) {
	        System.out.println("updateStatus(): " + ex);
	        ex.printStackTrace();
	    }
	}
	public double getTotalPaidAmount() {
	    double totalPaidAmount = 0.0;

	    try {
	        initJDBC();

	        // SQL query to get the total paid amount from the "bills" table
	        String sqlQuery = "SELECT SUM(bill_amount) AS totalAmount FROM bills WHERE bills_status = 'Paid'";

	        try (PreparedStatement ps = connection.prepareStatement(sqlQuery);
	             ResultSet rs = ps.executeQuery()) { // Use try-with-resources to automatically close resources

	            if (rs.next()) {
	                totalPaidAmount = rs.getDouble("totalAmount");
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    } catch (Exception ex) {
	        System.out.println("getTotalPaidAmount(): " + ex);
	        ex.printStackTrace();
	    } finally {
	        try {
	            connection.close(); // Close the database connection
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    return totalPaidAmount;
	}
	public boolean hasBillForAppointment(int appId) {
	    boolean hasBill = false;
	    try {
	        initJDBC();

	        String sqlQuery = "SELECT * FROM bills WHERE app_id = ?";
	        ps = connection.prepareStatement(sqlQuery);
	        ps.setInt(1, appId);

	        ResultSet rs = ps.executeQuery();
	        if (rs.next()) {
	            // If there's a result, it means there is a bill for this appointment
	            hasBill = true;
	        }

	        connection.close();
	    } catch (Exception ex) {
	        System.out.println("hasBillForAppointment(): " + ex);
	        ex.printStackTrace();
	    }

	    return hasBill;
	}


}