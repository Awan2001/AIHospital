package bills;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class PaymentProcess
 */
@WebServlet("/PaymentProcess")
public class PaymentProcess extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private billModel billM;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PaymentProcess() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String billstatus = request.getParameter("billstatus");
		String paymethod = request.getParameter("paymethod");
		int billid = Integer.parseInt(request.getParameter("billid"));
		int appid = Integer.parseInt(request.getParameter("appid"));
		double billamount = Double.parseDouble(request.getParameter("billamount"));
		String ptic = request.getParameter("patic");
		
		
		Bill bill = new Bill();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		Date billdate = null;
				
		try{
			billdate = format.parse(request.getParameter("billdate"));
			bill.setBillDate(billdate);
		} catch(ParseException e){
			e.printStackTrace();
		}

				
		bill.setBillId(billid);
		bill.setBillMethod(paymethod);
		bill.setBillStatus(billstatus);
		bill.setAppId(appid);
		bill.setBillAmmount(billamount);
		bill.setPtIc(ptic);
		
		try {
			billM = new billModel();
			billM.updateStatus(bill);
		}
		catch (Exception e) {
			e.printStackTrace();
			System.out.println("No data inserted in the table ");
		}
		request.getSession().setAttribute("pt_ic", ptic);
		response.sendRedirect("viewBills.jsp");
		
	}

}