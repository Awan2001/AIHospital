package bills;

import java.util.Date;

public class Bill {
	private int billId;
	private int appId;
	private Date billDate;
	private String billStatus;
	private double billAmmount;
	private String billMethod;
	private String ptIc;
	public Bill(int billId, int appId, Date billDate, String billStatus, double billAmmount, String billMethod,
			String ptIc) {
		super();
		this.billId = billId;
		this.appId = appId;
		this.billDate = billDate;
		this.billStatus = billStatus;
		this.billAmmount = billAmmount;
		this.billMethod = billMethod;
		this.ptIc = ptIc;
	}
	public Bill() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getBillId() {
		return billId;
	}
	public void setBillId(int billId) {
		this.billId = billId;
	}
	public int getAppId() {
		return appId;
	}
	public void setAppId(int appId) {
		this.appId = appId;
	}
	public Date getBillDate() {
		return billDate;
	}
	public void setBillDate(Date billDate) {
		this.billDate = billDate;
	}
	public String getBillStatus() {
		return billStatus;
	}
	public void setBillStatus(String billStatus) {
		this.billStatus = billStatus;
	}
	public double getBillAmmount() {
		return billAmmount;
	}
	public void setBillAmmount(double billAmmount) {
		this.billAmmount = billAmmount;
	}
	public String getBillMethod() {
		return billMethod;
	}
	public void setBillMethod(String billMethod) {
		this.billMethod = billMethod;
	}
	public String getPtIc() {
		return ptIc;
	}
	public void setPtIc(String ptIc) {
		this.ptIc = ptIc;
	}
	
	
	

}
