package patient;
import java.sql.*;
import java.util.ArrayList;

import doctor.Doctor;

public class patientModel {
	private Statement statement; 
	private PreparedStatement ps; 
	private Connection connection;
	
	public patientModel(Statement statement, PreparedStatement ps, Connection connection) {
		super();
		this.statement = statement;
		this.ps = ps;
		this.connection = connection;
	}
	
	public patientModel() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public void initJDBC() {
		try {
			//load JDBC
			Class.forName("com.mysql.jdbc.Driver");
			
			// Connect to a database
			 connection = DriverManager.getConnection
					("jdbc:mysql://localhost/ai_hospital" , "root", "");

			// Create a statement
			statement = connection.createStatement();
		}catch(Exception e) {
		}	
	 }
	public boolean validateLogin(String icNumber, String password) {
        boolean isValidLogin = false;
        try {
            // Prepare the SQL query with placeholders
            String query = "SELECT * FROM patients WHERE pt_ic = ? AND pt_pass = ?";
            try (PreparedStatement ps = connection.prepareStatement(query)) {
                // Set the placeholder values
                ps.setString(1, icNumber);
                ps.setString(2, password);

                // Execute the query
                try (ResultSet rs = ps.executeQuery()) {
                    // Check if a matching patient is found
                    isValidLogin = rs.next();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return isValidLogin;
    }
	
	public ArrayList<Patient> viewPatient(){	
		ArrayList<Patient> patientList = null;
		try {
			initJDBC();
			patientList = new ArrayList<Patient>();
			ResultSet rs = statement.executeQuery("SELECT * FROM patients");
			
			while(rs.next()){
				Patient pt= new Patient();
				pt.setIcNumber(rs.getString("pt_ic"));
				pt.setFirstName(rs.getString("pt_fname"));
				pt.setLastName(rs.getString("pt_lname"));
				pt.setAddress(rs.getString("pt_add"));
				pt.setPhoneNumber(rs.getString("pt_no"));
				pt.setPassword(rs.getString("pt_pass"));
				pt.setCpassword(rs.getString("pt_cpass"));
				//either way you also may use normal constructor to set values
				patientList.add(pt);
			}
			connection.close();
		}
		catch(Exception ex) {
			System.out.println("viewPatient(): "+ ex);
			ex.printStackTrace();
		}
		return patientList;
	}
	
	public Patient getPatientByIC(String icNo) {
	    Patient patient = new Patient();
	    try {
	        initJDBC();
	        String findPat = "SELECT * FROM patients WHERE pt_ic = ?";
	        try (PreparedStatement ps = connection.prepareStatement(findPat)) {
	            ps.setString(1, icNo);
	            try (ResultSet rs = ps.executeQuery()) {
	                if (rs.next()) {
	                    patient.setIcNumber(rs.getString("pt_ic"));
	                    patient.setFirstName(rs.getString("pt_fname"));
	                    patient.setLastName(rs.getString("pt_lname"));
	                    patient.setAddress(rs.getString("pt_add"));
	                    patient.setPhoneNumber(rs.getString("pt_no"));
	                    patient.setPassword(rs.getString("pt_pass"));
	                    patient.setCpassword(rs.getString("pt_cpass"));
	                }
	            }
	        }
	    } catch (Exception ex) {
	        System.out.println("getPatientByIC(): " + ex);
	        ex.printStackTrace();
	    }

	    return patient;
	}
	public void regPatient(Patient pat) {
		initJDBC();
		try {
			//buat sql insert statement
			String sql = "INSERT INTO patients (pt_ic, pt_fname, pt_lname, pt_add, pt_no, pt_pass, pt_cpass)"
		    		+ " VALUES (?, ?, ?, ?, ?, ?, ?)";
			//stmt value index=(1, 2, 3, 4, 5, 6, 7);
			//prepared statement
			PreparedStatement stmt = connection.prepareStatement(sql);
			// Set values for placeholders
		    stmt.setString(1, pat.getIcNumber());
		    stmt.setString(2, pat.getFirstName());
		    stmt.setString(3, pat.getLastName());
		    stmt.setString(4, pat.getAddress());
		    stmt.setString(5, pat.getPhoneNumber());
		    stmt.setString(6, pat.getPassword());
		    stmt.setString(7, pat.getCpassword());
		    

		    
		    //selesai set value bole la execute statement
		    stmt.executeUpdate();
			
		}catch(Exception ex){
			System.out.println("regPatient(): " +ex);
			ex.printStackTrace();
			
		}
	}
	public String getPatientName(String icNum) {
        Patient ptNm = new Patient();
        try {
            initJDBC();
            String findName = "SELECT pt_fname, pt_lname FROM patients WHERE pt_ic = ?";
            ps = connection.prepareStatement(findName);
            ps.setString(1, icNum); // Bind the parameter
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                ptNm.setFirstName(rs.getString("pt_fname"));
                ptNm.setLastName(rs.getString("pt_lname"));
            } else {
                System.out.println("No patient found for pt_ic: " + icNum);
            }

            connection.close();
        } catch (Exception ex) {
            System.out.println("getDepartmentNameById(): " + ex);
            ex.printStackTrace();
        }

        return ptNm.getFirstName()+" "+ptNm.getLastName();
    }
	public void updatePatient(Patient pat){
		 
		initJDBC();
		
		try{			
			String sqlUpdate = "UPDATE patients SET pt_fname = ?, pt_lname = ?,"
					+ " pt_add = ?, pt_no = ?,pt_pass = ?,pt_cpass = ?"
					+ " WHERE pt_ic = ?";
			
		    PreparedStatement stmt = connection.prepareStatement(sqlUpdate);
		    
			stmt.setString(1, pat.getFirstName());
			stmt.setString(2, pat.getLastName());
			stmt.setString(3, pat.getAddress());
			stmt.setString(4, pat.getPhoneNumber());
			stmt.setString(5, pat.getPassword());
			stmt.setString(6, pat.getCpassword());
			stmt.setString(7, pat.getIcNumber());
			
			//ps.executeUpdate();
			stmt.executeUpdate();
			
		}catch(Exception ex){
			System.out.println("updatePatient(): "+ex);
			ex.printStackTrace();	
		}
	}
	public int patientCount() {
	    int countpt = 0;
	    try {
	        initJDBC();
	        String countPat = "SELECT COUNT(*) AS rowCount FROM patients";
	        ps = connection.prepareStatement(countPat);
	        ResultSet rs = ps.executeQuery();

	        if (rs.next()) {
	            countpt = rs.getInt("rowCount");
	        }

	        connection.close();
	    } catch (Exception ex) {
	        System.out.println("patientCount(): " + ex);
	        ex.printStackTrace();
	    }
	    return countpt;
	}
}