package patient;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class patientRegistration
 */
@WebServlet("/patientRegistration")
public class patientRegistration extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public patientModel patModel;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public patientRegistration() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String icNum = request.getParameter("icNum");
		String patfname = request.getParameter("patfname");
		String patlname = request.getParameter("patlname");
		String patadd = request.getParameter("patadd");
		String patno = request.getParameter("patno");
		String patpass = request.getParameter("patpass");
		String cpatpass = request.getParameter("cpatpass");
				
		//declare object
		Patient patient =new Patient();
				
		patient.setIcNumber(icNum);
		patient.setFirstName(patfname);
		patient.setLastName(patlname);
		patient.setAddress(patadd);
		patient.setPhoneNumber(patno);
		patient.setPassword(patpass);
		patient.setCpassword(cpatpass);
		
		
		try {
			patModel = new patientModel();//initialize inventoryModel obj with InventoryModel method in InventoryModel.java
			patModel.regPatient(patient);//passing value of inventory obj to the addInventory method inside the inventoryModel obj
		}
		catch (Exception e) {
					e.printStackTrace();
					System.out.println("No data inserted in the table ");
				}
		response.sendRedirect("userlogin.jsp");
	}

}
