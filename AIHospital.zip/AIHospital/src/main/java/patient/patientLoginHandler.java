package patient;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class patientLoginHandler
 */
@WebServlet("/patientLoginHandler")
public class patientLoginHandler extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public patientLoginHandler() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get the IC Number and Password from the login form
        String icNumber = request.getParameter("icNumber");
        String password = request.getParameter("password");

        // Create an instance of the patientModel class
        patientModel patientModel = new patientModel();
        // Initialize JDBC connection
        patientModel.initJDBC();

        // Validate the login credentials
        boolean isValidLogin = patientModel.validateLogin(icNumber, password);

        if (isValidLogin) {
            // If login is successful, redirect the patient to a dashboard page or any other authenticated page.
        	HttpSession session = request.getSession();
        	session.setAttribute("icNo", icNumber);
            session.setAttribute("status", "patientloggedin");
            response.sendRedirect("index.jsp");
        } 		else {
			HttpSession session = request.getSession();
			session.setAttribute("danger", "Login failed... Please enter the correct IC Number and Password!");
			response.sendRedirect("userlogin.jsp");
		}
    }

}