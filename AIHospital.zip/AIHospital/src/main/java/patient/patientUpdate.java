package patient;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class patientUpdate
 */
@WebServlet("/patientUpdate")
public class patientUpdate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private patientModel ptModel;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public patientUpdate() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String ptIC = request.getParameter("ptIC");
		String patfname = request.getParameter("patfname");
		String patlname = request.getParameter("patlname");
		String patadd = request.getParameter("patadd");
		String patno = request.getParameter("patno");
		String patpass = request.getParameter("patpass");
		String patcpass = request.getParameter("patcpass");
				
		//declare object
		Patient patient = new Patient();
				
		patient.setIcNumber(ptIC);
		patient.setFirstName(patfname);
		patient.setLastName(patlname);
		patient.setAddress(patadd);
		patient.setPhoneNumber(patno);
		patient.setPassword(patpass);
		patient.setCpassword(patcpass);
		
		try {
			ptModel = new patientModel();
			ptModel.updatePatient(patient);
		}
		catch (Exception e) {
			e.printStackTrace();
			System.out.println("No data inserted in the table ");
		}
		response.sendRedirect("index.jsp");
	}

}
