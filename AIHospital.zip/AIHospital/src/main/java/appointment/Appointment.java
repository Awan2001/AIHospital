package appointment;

import java.util.Date;

public class Appointment {
	private int appID;
	private int docID;
	private String patIC;
	private int adminID;
	private String appCase;
	private Date appDate;
	public Appointment(int appID, int docID, String patIC, int adminID, String appCase, Date appDate) {
		super();
		this.appID = appID;
		this.docID = docID;
		this.patIC = patIC;
		this.adminID = adminID;
		this.appCase = appCase;
		this.appDate = appDate;
	}
	public Appointment() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getAppID() {
		return appID;
	}
	public void setAppID(int appID) {
		this.appID = appID;
	}
	public int getDocID() {
		return docID;
	}
	public void setDocID(int docID) {
		this.docID = docID;
	}
	public String getPatIC() {
		return patIC;
	}
	public void setPatIC(String patIC) {
		this.patIC = patIC;
	}
	public int getAdminID() {
		return adminID;
	}
	public void setAdminID(int adminID) {
		this.adminID = adminID;
	}
	public String getAppCase() {
		return appCase;
	}
	public void setAppCase(String appCase) {
		this.appCase = appCase;
	}
	public Date getAppDate() {
		return appDate;
	}
	public void setAppDate(Date appDate) {
		this.appDate = appDate;
	}
	

}
