package appointment;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;

/**
 * Servlet implementation class appointmentUpdate
 */
@WebServlet("/appointmentUpdate")
public class appointmentUpdate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private appointmentModel appModel;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public appointmentUpdate() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// Obtain data from the form
				int appID = Integer.parseInt(request.getParameter("appID"));
				int docID = Integer.parseInt(request.getParameter("doctorID"));
				int adminID = Integer.parseInt(request.getParameter("adminID"));
				String ptIC = request.getParameter("ptIC");
				String appCase = request.getParameter("appCase");
						
				//declare object
				Appointment app =new Appointment();
						
				app.setAppID(appID);
				app.setDocID(docID);
				app.setAdminID(adminID);
				app.setPatIC(ptIC);
				app.setAppCase(appCase);
						
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
				Date appDate = null;
						
				try{
					appDate = format.parse(request.getParameter("appDate"));
					app.setAppDate(appDate);
				} catch(ParseException e){
					e.printStackTrace();
				}
				try {
					appModel = new appointmentModel();
					appModel.updateApp(app);}
				catch (Exception e) {
							e.printStackTrace();
							System.out.println("No data inserted in the table ");
						}
				response.sendRedirect("viewApp.jsp");
	}

}
