package appointment;

import java.sql.*;
import java.util.ArrayList;

public class appointmentModel {
	private Statement statement; 
	private PreparedStatement ps; 
	private Connection connection;
	public appointmentModel(Statement statement, PreparedStatement ps, Connection connection) {
		super();
		this.statement = statement;
		this.ps = ps;
		this.connection = connection;
	}
	public appointmentModel() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public void initJDBC() {
		try {
			//load JDBC
			Class.forName("com.mysql.jdbc.Driver");
			
			// Connect to a database
			 connection = DriverManager.getConnection
					("jdbc:mysql://localhost/ai_hospital" , "root", "");

			// Create a statement
			statement = connection.createStatement();
		}catch(Exception e) {
		}	
	 }
	public ArrayList<Appointment> viewAppointment(){
		
		ArrayList<Appointment> appointmentList = null;
		try {
			initJDBC();
			appointmentList = new ArrayList<Appointment>();
			ResultSet rs = statement.executeQuery("SELECT * FROM appointment;");
			
			while(rs.next()){
				Appointment app= new Appointment();
				app.setAppID(rs.getInt("app_id"));
				app.setDocID(rs.getInt("doc_id"));
				app.setPatIC(rs.getString("pt_ic"));
				app.setAdminID(rs.getInt("admin_id"));
				app.setAppCase(rs.getString("app_case"));
				app.setAppDate(rs.getDate("app_date"));
				//either way you also may use normal constructor to set values
				appointmentList.add(app);
			}
			connection.close();
		}
		catch(Exception ex) {
			System.out.println("viewAppointment(): "+ ex);
			ex.printStackTrace();
		}
		
		return appointmentList;
	}
	
	public ArrayList<Appointment> ptViewApp(String ptIC) {
	    ArrayList<Appointment> appointmentList = new ArrayList<>();

	    try {
	        initJDBC();
	        String sql = "SELECT * FROM appointment WHERE pt_ic = ?";
	        PreparedStatement stmt = connection.prepareStatement(sql);
	        stmt.setString(1, ptIC);

	        ResultSet rs = stmt.executeQuery();
	        while (rs.next()) {
	            Appointment app = new Appointment();
	            app.setAppID(rs.getInt("app_id"));
	            app.setDocID(rs.getInt("doc_id"));
	            app.setPatIC(rs.getString("pt_ic"));
	            app.setAdminID(rs.getInt("admin_id"));
	            app.setAppCase(rs.getString("app_case"));
	            app.setAppDate(rs.getDate("app_date"));
	            appointmentList.add(app);
	        }

	        connection.close();
	    } catch (Exception ex) {
	        System.out.println("ptViewApp(): " + ex);
	        ex.printStackTrace();
	    }

	    return appointmentList;
	}

	
	public void makeAppointment(Appointment appointment) {
		initJDBC();
		try {
			//buat sql insert statement
			String sql = "INSERT INTO appointment (doc_id, pt_ic, admin_id, app_case, app_date)"
		    		+ " VALUES (?, ?, ?, ?, ?)";
			//stmt value index=(1, 2, 3, 4, 5);
			//prepared statement
			PreparedStatement stmt = connection.prepareStatement(sql);
			// Set values for placeholders
		    stmt.setInt(1, appointment.getDocID());
		    stmt.setString(2, appointment.getPatIC());
		    stmt.setInt(3, appointment.getAdminID());
		    stmt.setString(4, appointment.getAppCase());
		    stmt.setDate(5, new Date(appointment.getAppDate().getTime()));
		    

		    
		    //selesai set value bole la execute statement
		    stmt.executeUpdate();
			
		}catch(Exception ex){
			System.out.println("makeAppointment(): " +ex);
			ex.printStackTrace();
			
		}
	}
	
	public Appointment getAppointmentById(int appID) {
		Appointment upApp = new Appointment();
		try {
			initJDBC();
			String findApp = "SELECT * FROM appointment WHERE app_id =" + appID;
			ps = connection.prepareStatement(findApp);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				 
				 upApp.setAppID(rs.getInt(1));
				 upApp.setDocID(rs.getInt(2));
				 upApp.setPatIC(rs.getString(3));
				 upApp.setAdminID(rs.getInt(4));
				 upApp.setAppCase(rs.getString(5));
				 upApp.setAppDate(rs.getDate(6)); 
			 }
		}catch(Exception ex){
			System.out.println("getAppointmentById(): " +ex);
			ex.printStackTrace();
		}
		
		return upApp;
	}
	public void updateApp(Appointment app){
		 
		initJDBC();
		
		try{			
			String sqlUpdate = "UPDATE appointment SET doc_id = ?, pt_ic = ?,"
					+ " admin_id = ?, app_case = ?, app_date = ?"
					+ " WHERE app_id = ?";
			
		    PreparedStatement stmt = connection.prepareStatement(sqlUpdate);
		    
			stmt.setInt(1, app.getDocID());
			stmt.setString(2, app.getPatIC());
			stmt.setInt(3, app.getAdminID());
			stmt.setString(4,app.getAppCase() );
			stmt.setDate(5, new Date(app.getAppDate().getTime()));
			stmt.setInt(6, app.getAppID());
			
			//ps.executeUpdate();
			int i = stmt.executeUpdate();
			
		}catch(Exception ex){
			System.out.println("updateApp(): "+ex);
			ex.printStackTrace();	
		}
	}
	public void deleteAppointmentById(int appid) {
		try {
			initJDBC();
			String sqlDelete = "DELETE FROM appointment WHERE app_id = "+appid;
			ps = connection.prepareStatement(sqlDelete);
			ps.executeUpdate(sqlDelete);
			
		}catch(Exception ex) {
			System.out.println("deleteAppointmentById: "+ex );
			ex.printStackTrace();
		}
	}

}
