package department;

import java.sql.*;
import java.util.ArrayList;

public class departmentModel {
    private Statement statement;
    private PreparedStatement ps;
    private Connection connection;

    public departmentModel(Statement statement, PreparedStatement ps, Connection connection) {
        super();
        this.statement = statement;
        this.ps = ps;
        this.connection = connection;
    }

    public departmentModel() {
        super();
        // TODO Auto-generated constructor stub
    }

    public void initJDBC() {
        try {
            // Load JDBC
            Class.forName("com.mysql.jdbc.Driver");

            // Connect to a database
            connection = DriverManager.getConnection("jdbc:mysql://localhost/ai_hospital", "root", "");

            // Create a statement
            statement = connection.createStatement();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ArrayList<Department> viewDepartment() {
        ArrayList<Department> departmentList = null;
        try {
            initJDBC();
            departmentList = new ArrayList<Department>();
            ResultSet rs = statement.executeQuery("SELECT * FROM departments");

            while (rs.next()) {
                Department dept = new Department();
                dept.setDepartmentID(rs.getInt("dept_id"));
                dept.setDepartmentName(rs.getString("dept_name"));
                departmentList.add(dept);
            }
            connection.close();
        } catch (Exception ex) {
            System.out.println("viewDepartment(): " + ex);
            ex.printStackTrace();
        }

        return departmentList;
    }

    public String getDepartmentNameById(int deptID) {
        Department DeptN = new Department();
        try {
            initJDBC();
            String findID = "SELECT dept_name FROM departments WHERE dept_id = ?";
            ps = connection.prepareStatement(findID);
            ps.setInt(1, deptID); // Bind the parameter
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                DeptN.setDepartmentName(rs.getString("dept_name"));
            } else {
                System.out.println("No department found for dept_id: " + deptID);
            }

            connection.close();
        } catch (Exception ex) {
            System.out.println("getDepartmentNameById(): " + ex);
            ex.printStackTrace();
        }

        return DeptN.getDepartmentName();
    }
}
